import json
from django.views.generic.base import TemplateView
from django.views.generic import View
from django.http import JsonResponse
from chatterbot import ChatBot
from chatterbot.ext.django_chatterbot import settings
from django.shortcuts import render


from example_app.trainedmodel import predictEmotion

Sad=10
Joy=10
Anger=10
Fear=10





class ChatterBotAppView(TemplateView):
    template_name = 'app.html'


class ChatterBotApiView(View):
    """
    Provide an API endpoint to interact with ChatterBot.
    """
    pe = predictEmotion()

    #def __init__(self):
    #   self.pe = predictEmotion()
    #    print('created.......obj')
    #    super()

    chatterbot = ChatBot(**settings.CHATTERBOT)


    def post(self, request, *args, **kwargs):
        """
        Return a response to the statement in the posted data.
        * The JSON data should contain a 'text' attribute.
        """
        input_data = json.loads(request.body.decode('utf-8'))

        if 'text' not in input_data:
            return JsonResponse({
                'text': [
                    'The attribute "text" is required.'
                ]
            }, status=400)

        response = self.chatterbot.get_response(input_data)

        response_data = response.serialize()


        emotion = ChatterBotApiView.pe.perdt(input_data['text'])

        if emotion == 'Fear':
            global Fear
            Fear+=1
        elif emotion == 'Sad':
            global Sad
            Sad += 1
        elif emotion == 'Joy':
            global Joy
            Joy += 1
        elif emotion == 'Anger':
            global Anger
            Anger += 1
        else:
            pass

        #print(emotion)

        #print(id(self.pe))

        return JsonResponse(response_data, status=200)

    def get(self, request, *args, **kwargs):
        """
        Return data corresponding to the current conversation.
        """
        return JsonResponse({
            'name': self.chatterbot.name
        })

class EmotionAppView(TemplateView):

    def get(self, request, *args, **kwargs):
        """
        Return data corresponding to the current conversation.
        """
        context = {"e1":Joy,
                   "e2": Sad,
                   "e3": Anger,
                   "e4": Fear}
        template_name = 'Emotion.html'
        return render(request, template_name, context)






class SummaryAppView(TemplateView):

    def get(self, request, *args, **kwargs):
        """
        Return data corresponding to the current conversation.
        """
        context = {"e1":Joy,
                   "e2": Sad,
                   "e3": Anger,
                   "e4": Fear}
        template_name = 'Summary.html'
        return render(request, template_name, context)






