from django.conf.urls import url
from django.contrib import admin
from example_app.views import ChatterBotAppView, ChatterBotApiView,EmotionAppView,SummaryAppView



urlpatterns = [
    url(r'^$', ChatterBotAppView.as_view(), name='main'),
    url(r'^admin/', admin.site.urls, name='admin'),
    url(r'^api/chatterbot/', ChatterBotApiView.as_view(), name='chatterbot'),
    url(r'^api/emotions/', EmotionAppView.as_view(), name='emotions'),
    url(r'^api/summary/', SummaryAppView.as_view(), name='summary'),
]
