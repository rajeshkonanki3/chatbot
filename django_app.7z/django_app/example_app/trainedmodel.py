from transformers import BertTokenizer
from transformers import BertForSequenceClassification
import torch


class predictEmotion(object):
    def __init__(self):
        super()
        self.model = BertForSequenceClassification.from_pretrained('F:\Deals\Project NLP\Model', num_labels=4)
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', do_lower_case=True)
    def perdt(self,sent):
        # Tokenize all of the sentences and map the tokens to thier word IDs.
        input_ids = []
        #sent='The race advances only by the extra achievements of the individual. You are the individual. ~Charles Towne\n  #inspire'
        # For every sentence...
        # `encode` will:
        #   (1) Tokenize the sentence.
        #   (2) Prepend the `[CLS]` token to the start.
        #   (3) Append the `[SEP]` token to the end.
        #   (4) Map tokens to their IDs.
        encoded_sent = self.tokenizer.encode(sent,add_special_tokens = True,)
        input_ids.append(encoded_sent)
        attention_masks = []

        # Create a mask of 1s for each token followed by 0s for padding
        for seq in input_ids:
            seq_mask = [float(i > 0) for i in seq]
            attention_masks.append(seq_mask)

        prediction_inputs = torch.tensor(input_ids)
        prediction_masks = torch.tensor(attention_masks)

        outputs = self.model(prediction_inputs, token_type_ids=None,
                attention_mask=prediction_masks)
        emotion = ['Anger', 'Fear', 'Joy', 'Sad']
        logits = outputs[0]
        #print(torch.abs(logits))
        x=torch.argmax(torch.abs(logits))
        #print(torch.argmax(torch.abs(logits)))
        #print(emotion[int(x.item())])
        return emotion[int(x.item())]


